import pandas as pd # Задание 1
import matplotlib.pyplot as plt # Задание 2
import numpy as np # Задание 3
    
data = pd.read_csv('Airpollution.csv') # Задание 4
print ("First 10 row:\n",data.head(10)) # Задание 5